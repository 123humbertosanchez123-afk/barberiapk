import { useState, useEffect } from "react";
import SplashScreen from "./screens/SplashScreen";
import LoginScreen from "./screens/LoginScreen";
import RegisterScreen from "./screens/RegisterScreen";
import HomeScreen from "./screens/HomeScreen";
import CalendarScreen from "./screens/CalendarScreen";
import ProfileScreen from "./screens/ProfileScreen";
import RatingScreen from "./screens/RatingScreen";
import BottomNav from "./components/BottomNav";
import type { UserData } from "./screens/RegisterScreen";
import type { BookingData } from "./screens/CalendarScreen";

type Screen =
  | "splash"
  | "login"
  | "register"
  | "home"
  | "calendar"
  | "profile"
  | "rating";

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [user, setUser] = useState<UserData | null>(null);
  const [pendingBooking, setPendingBooking] = useState<{ service?: string; professional?: string } | null>(null);
  const [lastBooking, setLastBooking] = useState<BookingData | null>(null);
  const [activeNav, setActiveNav] = useState("home");

  // Show rating modal after booking
  useEffect(() => {
    if (lastBooking) {
      const t = setTimeout(() => setScreen("rating"), 3000);
      return () => clearTimeout(t);
    }
  }, [lastBooking]);

  const handleLogin = () => {
    setUser({
      nombre: "Carlos",
      apellido: "Gómez",
      documento: "1020304050",
      telefono: "+57 310 555 0000",
      direccion: "Calle 50 # 80-20, Medellín",
      codigoInvitacion: "",
      photo: null,
      inviteCode: "BAR-GOM501",
    });
    setScreen("home");
    setActiveNav("home");
  };

  const handleRegister = (data: UserData) => {
    setUser(data);
    setScreen("home");
    setActiveNav("home");
  };

  const handleBook = (serviceId: string, professionalId: string) => {
    setPendingBooking({ service: serviceId, professional: professionalId });
    setScreen("calendar");
    setActiveNav("calendar");
  };

  const handleBooked = (booking: BookingData) => {
    setLastBooking(booking);
    setPendingBooking(null);
  };

  const handleNav = (id: string) => {
    setActiveNav(id);
    if (id === "home") setScreen("home");
    if (id === "calendar") setScreen("calendar");
    if (id === "profile") setScreen("profile");
  };

  const showBottomNav = user && !["splash", "login", "register", "rating"].includes(screen);

  return (
    <div className="mobile-container">
      {/* Splash */}
      {screen === "splash" && (
        <SplashScreen onDone={() => setScreen("login")} />
      )}

      {/* Auth */}
      {screen === "login" && (
        <LoginScreen onLogin={handleLogin} onGoRegister={() => setScreen("register")} />
      )}
      {screen === "register" && (
        <RegisterScreen onRegister={handleRegister} onBack={() => setScreen("login")} />
      )}

      {/* Main app */}
      {user && screen === "home" && (
        <HomeScreen user={user} onBook={handleBook} />
      )}
      {user && screen === "calendar" && (
        <CalendarScreen
          preSelectedService={pendingBooking?.service}
          preSelectedProfessional={pendingBooking?.professional}
          onBooked={handleBooked}
        />
      )}
      {user && screen === "profile" && (
        <ProfileScreen
          user={user}
          onLogout={() => { setUser(null); setScreen("login"); }}
          onRateService={() => setScreen("rating")}
        />
      )}
      {user && screen === "rating" && (
        <RatingScreen
          professionalName={lastBooking ? "Carlos Mendoza" : "Andrés Ríos"}
          serviceName={lastBooking ? "Corte Clásico" : "Fade / Degradado"}
          onSubmit={() => { setLastBooking(null); setScreen("home"); setActiveNav("home"); }}
          onSkip={() => { setLastBooking(null); setScreen("home"); setActiveNav("home"); }}
        />
      )}

      {/* Bottom nav */}
      {showBottomNav && (
        <BottomNav active={activeNav} onNav={handleNav} />
      )}
    </div>
  );
}
