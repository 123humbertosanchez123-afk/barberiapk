import { useEffect, useState } from "react";

interface SplashScreenProps {
  onDone: () => void;
}

export default function SplashScreen({ onDone }: SplashScreenProps) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 300);
    const t2 = setTimeout(() => setPhase(2), 1000);
    const t3 = setTimeout(() => setPhase(3), 1800);
    const t4 = setTimeout(() => onDone(), 3200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, [onDone]);

  return (
    <div
      className="flex flex-col items-center justify-center h-full relative overflow-hidden"
      style={{ background: "radial-gradient(ellipse at center, #1a1200 0%, #0c0c0c 70%)" }}
    >
      {/* Ambient rings */}
      {phase >= 1 && (
        <>
          <div
            className="absolute rounded-full border border-yellow-600/10 animate-ring-expand"
            style={{ width: 280, height: 280 }}
          />
          <div
            className="absolute rounded-full border border-yellow-600/10 animate-ring-expand"
            style={{ width: 280, height: 280, animationDelay: "0.5s" }}
          />
          <div
            className="absolute rounded-full border border-yellow-600/10 animate-ring-expand"
            style={{ width: 280, height: 280, animationDelay: "1s" }}
          />
        </>
      )}

      {/* Logo group */}
      <div
        className="flex flex-col items-center gap-6 z-10"
        style={{
          opacity: phase >= 1 ? 1 : 0,
          transition: "opacity 0.5s ease",
        }}
      >
        {/* Animated scissor logo */}
        <div
          className={phase >= 1 ? "animate-logo-reveal" : ""}
          style={{ animationDelay: "0.1s", opacity: 0 }}
        >
          <div
            className="relative flex items-center justify-center rounded-full animate-gold-pulse"
            style={{
              width: 120,
              height: 120,
              background: "linear-gradient(135deg, #1a1200, #2a2000)",
              border: "2px solid #c9a84c",
              boxShadow: "0 0 40px #c9a84c44, inset 0 0 20px #c9a84c11",
            }}
          >
            {/* Outer ring spin */}
            <div
              className="absolute rounded-full animate-spin-slow"
              style={{
                width: 112,
                height: 112,
                border: "1px dashed #c9a84c44",
                borderRadius: "50%",
              }}
            />
            <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
              {/* Scissors */}
              <g transform="translate(30,30)">
                {/* Blade 1 */}
                <line x1="-18" y1="-18" x2="0" y2="0" stroke="#c9a84c" strokeWidth="3" strokeLinecap="round" />
                <line x1="-10" y1="-18" x2="0" y2="0" stroke="#c9a84c" strokeWidth="3" strokeLinecap="round" />
                <circle cx="-14" cy="-22" r="5" stroke="#c9a84c" strokeWidth="2" fill="none" />
                {/* Blade 2 */}
                <line x1="18" y1="18" x2="0" y2="0" stroke="#d4af37" strokeWidth="3" strokeLinecap="round" />
                <line x1="10" y1="18" x2="0" y2="0" stroke="#d4af37" strokeWidth="3" strokeLinecap="round" />
                <circle cx="14" cy="22" r="5" stroke="#d4af37" strokeWidth="2" fill="none" />
                {/* Center pivot */}
                <circle cx="0" cy="0" r="3" fill="#c9a84c" />
                {/* Comb lines */}
                <line x1="4" y1="-10" x2="4" y2="-2" stroke="#c9a84c88" strokeWidth="1.5" />
                <line x1="7" y1="-10" x2="7" y2="-2" stroke="#c9a84c88" strokeWidth="1.5" />
                <line x1="10" y1="-10" x2="10" y2="-2" stroke="#c9a84c88" strokeWidth="1.5" />
                <line x1="13" y1="-10" x2="13" y2="-2" stroke="#c9a84c88" strokeWidth="1.5" />
              </g>
            </svg>
          </div>
        </div>

        {/* Name */}
        <div
          style={{
            opacity: phase >= 2 ? 1 : 0,
            transform: phase >= 2 ? "translateY(0)" : "translateY(10px)",
            transition: "all 0.6s cubic-bezier(0.34,1.56,0.64,1)",
          }}
          className="flex flex-col items-center gap-1"
        >
          <h1 className="font-display text-5xl font-900 gold-shimmer tracking-wide">
            ÉLITE
          </h1>
          <p className="text-xs font-300 tracking-[0.4em] uppercase" style={{ color: "#7a6a40" }}>
            Barbershop
          </p>
        </div>

        {/* Tagline */}
        <div
          style={{
            opacity: phase >= 3 ? 1 : 0,
            transform: phase >= 3 ? "translateY(0)" : "translateY(8px)",
            transition: "all 0.5s ease",
          }}
        >
          <p className="text-xs text-center" style={{ color: "#555", letterSpacing: "0.1em" }}>
            Tu estilo, nuestra pasión
          </p>
        </div>
      </div>

      {/* Loading bar */}
      <div
        className="absolute bottom-16 left-8 right-8"
        style={{ opacity: phase >= 2 ? 1 : 0, transition: "opacity 0.4s" }}
      >
        <div className="h-px w-full rounded-full" style={{ background: "#2a2a2a" }}>
          <div
            className="h-px rounded-full"
            style={{
              background: "linear-gradient(90deg, #c9a84c, #d4af37)",
              width: phase >= 3 ? "100%" : "60%",
              transition: "width 1s ease",
              boxShadow: "0 0 8px #c9a84c88",
            }}
          />
        </div>
      </div>
    </div>
  );
}
