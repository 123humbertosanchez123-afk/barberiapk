import { useState, useRef, useCallback } from "react";
import { generateCode } from "../data/mockData";

interface RegisterScreenProps {
  onRegister: (data: UserData) => void;
  onBack: () => void;
}

export interface UserData {
  nombre: string;
  apellido: string;
  documento: string;
  telefono: string;
  direccion: string;
  codigoInvitacion: string;
  photo: string | null;
  inviteCode: string;
}

export default function RegisterScreen({ onRegister, onBack }: RegisterScreenProps) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    nombre: "", apellido: "", documento: "", telefono: "", direccion: "", codigoInvitacion: "",
  });
  const [photo, setPhoto] = useState<string | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const openCamera = async () => {
    setCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch {
      alert("No se pudo acceder a la cámara. Usa un navegador con permisos de cámara.");
      setCameraOpen(false);
    }
  };

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext("2d");
    if (!ctx) return;
    canvasRef.current.width = videoRef.current.videoWidth || 300;
    canvasRef.current.height = videoRef.current.videoHeight || 300;
    ctx.drawImage(videoRef.current, 0, 0);
    const dataUrl = canvasRef.current.toDataURL("image/jpeg", 0.85);
    setPhoto(dataUrl);
    stopCamera();
  }, []);

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOpen(false);
  };

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    setLoading(true);
    setTimeout(() => {
      onRegister({ ...form, photo, inviteCode: generateCode() });
    }, 1200);
  };

  const stepOneValid = form.nombre && form.apellido && form.documento && form.telefono;
  const stepTwoValid = photo !== null;

  return (
    <div
      className="flex flex-col h-full overflow-y-auto"
      style={{ background: "#0c0c0c" }}
    >
      {/* Header */}
      <div
        className="flex items-center gap-3 px-5 py-5 sticky top-0 z-20"
        style={{ background: "#0c0c0c", borderBottom: "1px solid #1e1e1e" }}
      >
        <button onClick={onBack} className="p-2 rounded-lg" style={{ background: "#1a1a1a" }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
        <div>
          <h2 className="font-display text-lg font-bold" style={{ color: "#f0ece0" }}>
            Crear cuenta
          </h2>
          <p className="text-xs" style={{ color: "#555" }}>
            Paso {step} de 3
          </p>
        </div>
        {/* Step dots */}
        <div className="ml-auto flex gap-2">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className="h-1.5 rounded-full transition-all duration-300"
              style={{
                width: step === s ? 20 : 6,
                background: step >= s ? "#c9a84c" : "#2a2a2a",
              }}
            />
          ))}
        </div>
      </div>

      <div className="flex-1 px-5 py-6">
        {/* Step 1: Datos personales */}
        {step === 1 && (
          <div className="flex flex-col gap-4 animate-fade-up">
            <h3 className="text-base font-semibold" style={{ color: "#c9a84c" }}>
              Datos personales
            </h3>
            {[
              { key: "nombre", label: "Nombre", placeholder: "Juan", type: "text" },
              { key: "apellido", label: "Apellido", placeholder: "Pérez", type: "text" },
              { key: "documento", label: "Documento de identidad", placeholder: "1234567890", type: "text" },
              { key: "telefono", label: "Teléfono", placeholder: "+57 300 000 0000", type: "tel" },
              { key: "direccion", label: "Dirección", placeholder: "Calle 10 # 20-30", type: "text" },
              { key: "codigoInvitacion", label: "Código de invitación (opcional)", placeholder: "BAR-XXXXXX", type: "text" },
            ].map(({ key, label, placeholder, type }) => (
              <div key={key}>
                <label className="text-xs font-medium mb-1 block" style={{ color: "#7a7a7a" }}>
                  {label}
                </label>
                <input
                  className="input-dark"
                  type={type}
                  placeholder={placeholder}
                  value={(form as Record<string, string>)[key]}
                  onChange={(e) => set(key, e.target.value)}
                />
              </div>
            ))}

            <button
              className="btn-primary w-full py-4 mt-2 text-sm font-bold tracking-wider"
              onClick={() => setStep(2)}
              disabled={!stepOneValid}
              style={{ opacity: stepOneValid ? 1 : 0.4 }}
            >
              CONTINUAR
            </button>
          </div>
        )}

        {/* Step 2: Foto */}
        {step === 2 && (
          <div className="flex flex-col gap-5 items-center animate-fade-up">
            <h3 className="text-base font-semibold self-start" style={{ color: "#c9a84c" }}>
              Foto de perfil
            </h3>
            <p className="text-sm self-start" style={{ color: "#7a7a7a" }}>
              Toma una foto directamente con tu cámara para identificarte en el sistema
            </p>

            {/* Camera / Photo display */}
            {cameraOpen ? (
              <div className="flex flex-col items-center gap-4 w-full">
                <div
                  className="relative rounded-2xl overflow-hidden"
                  style={{
                    width: 260,
                    height: 260,
                    border: "2px solid #c9a84c",
                    boxShadow: "0 0 20px #c9a84c33",
                  }}
                >
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                    style={{ transform: "scaleX(-1)" }}
                  />
                  {/* Guide overlay */}
                  <div
                    className="absolute inset-0"
                    style={{
                      background: "linear-gradient(to bottom, transparent 20%, #00000044 100%)",
                    }}
                  />
                  <div
                    className="absolute rounded-full"
                    style={{
                      width: 180, height: 180,
                      border: "2px dashed #c9a84c88",
                      top: "50%", left: "50%",
                      transform: "translate(-50%,-50%)",
                    }}
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    className="py-3 px-6 rounded-xl text-sm font-semibold"
                    style={{ background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#f0ece0" }}
                    onClick={stopCamera}
                  >
                    Cancelar
                  </button>
                  <button className="btn-primary py-3 px-8 text-sm font-bold" onClick={capturePhoto}>
                    📸 Capturar
                  </button>
                </div>
                <canvas ref={canvasRef} className="hidden" />
              </div>
            ) : photo ? (
              <div className="flex flex-col items-center gap-4">
                <div
                  className="rounded-2xl overflow-hidden"
                  style={{
                    width: 200,
                    height: 200,
                    border: "3px solid #c9a84c",
                    boxShadow: "0 0 24px #c9a84c44",
                  }}
                >
                  <img src={photo} alt="Foto de perfil" className="w-full h-full object-cover" />
                </div>
                <button
                  className="text-xs py-2 px-4 rounded-lg"
                  style={{ background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#c9a84c" }}
                  onClick={openCamera}
                >
                  Tomar otra foto
                </button>
              </div>
            ) : (
              <button
                className="flex flex-col items-center gap-3 py-12 px-16 rounded-2xl"
                style={{
                  border: "2px dashed #c9a84c44",
                  background: "#111",
                }}
                onClick={openCamera}
              >
                <div
                  className="rounded-full flex items-center justify-center"
                  style={{ width: 64, height: 64, background: "#1a1200" }}
                >
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="1.5">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" />
                    <circle cx="12" cy="13" r="4" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ color: "#f0ece0" }}>Abrir cámara</p>
                  <p className="text-xs" style={{ color: "#555" }}>Toca para tomar tu foto</p>
                </div>
              </button>
            )}

            <div className="flex gap-3 w-full mt-4">
              <button
                className="flex-1 py-4 rounded-xl text-sm font-medium"
                style={{ background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#f0ece0" }}
                onClick={() => setStep(1)}
              >
                Atrás
              </button>
              <button
                className="btn-primary flex-1 py-4 text-sm font-bold"
                onClick={() => setStep(3)}
                disabled={!stepTwoValid}
                style={{ opacity: stepTwoValid ? 1 : 0.4 }}
              >
                CONTINUAR
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Resumen */}
        {step === 3 && (
          <div className="flex flex-col gap-4 animate-fade-up">
            <h3 className="text-base font-semibold" style={{ color: "#c9a84c" }}>
              Confirma tus datos
            </h3>

            <div className="flex items-center gap-4 p-4 rounded-2xl" style={{ background: "#161616", border: "1px solid #2a2a2a" }}>
              {photo && (
                <img
                  src={photo}
                  alt="Tu foto"
                  className="rounded-full object-cover"
                  style={{ width: 64, height: 64, border: "2px solid #c9a84c" }}
                />
              )}
              <div>
                <p className="font-semibold text-base" style={{ color: "#f0ece0" }}>
                  {form.nombre} {form.apellido}
                </p>
                <p className="text-xs" style={{ color: "#7a7a7a" }}>{form.telefono}</p>
                <p className="text-xs" style={{ color: "#7a7a7a" }}>{form.documento}</p>
              </div>
            </div>

            {[
              { label: "Dirección", value: form.direccion },
              form.codigoInvitacion ? { label: "Código de invitación", value: form.codigoInvitacion } : null,
            ].filter(Boolean).map((item) => (
              <div
                key={item!.label}
                className="flex justify-between items-center p-3 rounded-xl"
                style={{ background: "#111", border: "1px solid #1e1e1e" }}
              >
                <span className="text-xs" style={{ color: "#7a7a7a" }}>{item!.label}</span>
                <span className="text-sm font-medium" style={{ color: "#f0ece0" }}>{item!.value}</span>
              </div>
            ))}

            <div
              className="p-4 rounded-2xl flex items-center gap-3"
              style={{ background: "#0f0e00", border: "1px solid #c9a84c33" }}
            >
              <span style={{ fontSize: 24 }}>🎁</span>
              <div>
                <p className="text-xs font-medium" style={{ color: "#c9a84c" }}>Se generará tu código de invitación</p>
                <p className="text-xs" style={{ color: "#555" }}>Compártelo y gana beneficios exclusivos</p>
              </div>
            </div>

            <div className="flex gap-3 mt-2">
              <button
                className="flex-1 py-4 rounded-xl text-sm font-medium"
                style={{ background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#f0ece0" }}
                onClick={() => setStep(2)}
              >
                Atrás
              </button>
              <button
                className="btn-primary flex-1 py-4 text-sm font-bold tracking-wider flex items-center justify-center gap-2"
                onClick={handleSubmit}
                disabled={loading}
              >
                {loading ? (
                  <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
                    <path d="M12 2a10 10 0 0 1 10 10" />
                  </svg>
                ) : "REGISTRARME"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
