import { useState } from "react";
import type { UserData } from "./RegisterScreen";

interface ProfileScreenProps {
  user: UserData;
  onLogout: () => void;
  onRateService: () => void;
}

export default function ProfileScreen({ user, onLogout, onRateService }: ProfileScreenProps) {
  const [codeCopied, setCodeCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(user.inviteCode).catch(() => {});
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const stats = [
    { label: "Citas", value: "12" },
    { label: "Reseñas", value: "8" },
    { label: "Invitados", value: "3" },
  ];

  const history = [
    { service: "Corte Clásico", professional: "Carlos Mendoza", date: "12 Ago 2026", price: "$25.000", rated: true },
    { service: "Fade / Degradado", professional: "Andrés Ríos", date: "28 Jul 2026", price: "$35.000", rated: false },
    { service: "Combo Caballero", professional: "Carlos Mendoza", date: "10 Jul 2026", price: "$55.000", rated: true },
  ];

  return (
    <div className="screen-scroll">
      {/* Profile header */}
      <div
        className="px-5 pt-10 pb-6 flex flex-col items-center"
        style={{ background: "linear-gradient(180deg, #1a1200 0%, #0c0c0c 100%)" }}
      >
        <div className="relative mb-3">
          <div
            className="rounded-full overflow-hidden"
            style={{
              width: 96,
              height: 96,
              border: "3px solid #c9a84c",
              boxShadow: "0 0 24px #c9a84c44",
            }}
          >
            {user.photo ? (
              <img src={user.photo} alt="Foto de perfil" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: "#1a1200" }}>
                <span className="font-display text-4xl font-bold" style={{ color: "#c9a84c" }}>
                  {user.nombre[0]}
                </span>
              </div>
            )}
          </div>
          <div
            className="absolute -bottom-1 -right-1 rounded-full flex items-center justify-center"
            style={{ width: 28, height: 28, background: "#c9a84c", border: "2px solid #0c0c0c" }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2.5">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
          </div>
        </div>

        <h2 className="font-display text-2xl font-bold" style={{ color: "#f0ece0" }}>
          {user.nombre} {user.apellido}
        </h2>
        <p className="text-xs mt-1" style={{ color: "#7a7a7a" }}>{user.telefono}</p>

        {/* Stats */}
        <div className="flex items-center gap-8 mt-5">
          {stats.map(({ label, value }) => (
            <div key={label} className="flex flex-col items-center">
              <span className="font-display text-2xl font-bold" style={{ color: "#c9a84c" }}>{value}</span>
              <span className="text-xs" style={{ color: "#555" }}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Info cards */}
      <div className="px-5 py-5 flex flex-col gap-3">
        {/* Invite code */}
        <div
          className="p-4 rounded-2xl"
          style={{ background: "#0f0e00", border: "1px solid #c9a84c44" }}
        >
          <p className="text-xs font-semibold mb-2" style={{ color: "#c9a84c" }}>
            🎁 Tu código de invitación
          </p>
          <div className="flex items-center justify-between gap-3">
            <span
              className="font-mono text-lg font-bold tracking-wider"
              style={{ color: "#f0ece0" }}
            >
              {user.inviteCode}
            </span>
            <button
              className="flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold transition-all"
              style={{
                background: codeCopied ? "#0a1a0a" : "#1a1200",
                border: `1px solid ${codeCopied ? "#22c55e" : "#c9a84c44"}`,
                color: codeCopied ? "#22c55e" : "#c9a84c",
              }}
              onClick={copyCode}
            >
              {codeCopied ? (
                <>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  Copiado
                </>
              ) : (
                <>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" />
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                  </svg>
                  Copiar
                </>
              )}
            </button>
          </div>
          <p className="text-xs mt-2" style={{ color: "#555" }}>
            Comparte este código y gana descuentos exclusivos
          </p>
        </div>

        {/* Personal data */}
        <div className="card-dark p-4 rounded-2xl flex flex-col gap-2">
          <p className="text-xs font-semibold mb-1" style={{ color: "#c9a84c" }}>Datos personales</p>
          {[
            { icon: "📋", label: "Documento", value: user.documento },
            { icon: "📍", label: "Dirección", value: user.direccion || "No registrada" },
            { icon: "📱", label: "Teléfono", value: user.telefono },
          ].map(({ icon, label, value }) => (
            <div key={label} className="flex items-center gap-3 py-2" style={{ borderBottom: "1px solid #1e1e1e" }}>
              <span style={{ fontSize: 16 }}>{icon}</span>
              <div>
                <p className="text-xs" style={{ color: "#555" }}>{label}</p>
                <p className="text-sm font-medium" style={{ color: "#f0ece0" }}>{value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Service history */}
        <div>
          <p className="text-xs font-medium tracking-wider mb-3 uppercase" style={{ color: "#7a7a7a" }}>
            Historial de servicios
          </p>
          <div className="flex flex-col gap-2">
            {history.map((item, i) => (
              <div
                key={i}
                className="p-4 rounded-2xl flex items-center gap-3"
                style={{ background: "#161616", border: "1px solid #2a2a2a" }}
              >
                <div
                  className="rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ width: 40, height: 40, background: "#0f0e00" }}
                >
                  <span style={{ fontSize: 18 }}>✂️</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold" style={{ color: "#f0ece0" }}>{item.service}</p>
                  <p className="text-xs" style={{ color: "#7a7a7a" }}>{item.professional}</p>
                  <p className="text-xs" style={{ color: "#555" }}>{item.date}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-sm font-bold" style={{ color: "#c9a84c" }}>{item.price}</span>
                  {!item.rated && (
                    <button
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={{ background: "#1a1200", border: "1px solid #c9a84c44", color: "#c9a84c" }}
                      onClick={onRateService}
                    >
                      ★ Calificar
                    </button>
                  )}
                  {item.rated && (
                    <span className="text-xs" style={{ color: "#555" }}>★★★★★</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Logout */}
        <button
          className="w-full py-4 rounded-xl text-sm font-semibold mt-2 flex items-center justify-center gap-2"
          style={{ background: "#1a0a0a", border: "1px solid #3a1a1a", color: "#cc4444" }}
          onClick={onLogout}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
          Cerrar sesión
        </button>
      </div>
    </div>
  );
}
