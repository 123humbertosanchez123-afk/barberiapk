import { useState } from "react";

interface RatingScreenProps {
  professionalName?: string;
  serviceName?: string;
  onSubmit: () => void;
  onSkip: () => void;
}

export default function RatingScreen({ professionalName = "Carlos Mendoza", serviceName = "Corte Clásico", onSubmit, onSkip }: RatingScreenProps) {
  const [stars, setStars] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [tags, setTags] = useState<string[]>([]);

  const quickTags = ["Excelente corte", "Muy puntual", "Buen ambiente", "Trato amable", "Precio justo", "Recomendaría"];

  const toggleTag = (t: string) => setTags(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(() => onSubmit(), 2000);
  };

  const starLabels = ["", "Malo", "Regular", "Bueno", "Muy bueno", "Excelente"];

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-5 px-8">
        <div
          className="rounded-full flex items-center justify-center animate-logo-reveal"
          style={{ width: 90, height: 90, background: "#0f0e00", border: "3px solid #c9a84c", boxShadow: "0 0 30px #c9a84c44" }}
        >
          <span style={{ fontSize: 40 }}>🌟</span>
        </div>
        <div className="text-center">
          <h2 className="font-display text-2xl font-bold mb-2" style={{ color: "#f0ece0" }}>
            ¡Gracias por tu opinión!
          </h2>
          <p className="text-sm" style={{ color: "#7a7a7a" }}>
            Tu calificación nos ayuda a mejorar cada día
          </p>
        </div>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((s) => (
            <span key={s} style={{ fontSize: 28, color: s <= stars ? "#c9a84c" : "#2a2a2a" }}>★</span>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Header */}
      <div
        className="flex flex-col items-center px-5 pt-10 pb-8"
        style={{ background: "linear-gradient(180deg, #1a1200 0%, #0c0c0c 100%)" }}
      >
        <div
          className="rounded-full flex items-center justify-center mb-4"
          style={{
            width: 72,
            height: 72,
            background: "#0f0e00",
            border: "2px solid #c9a84c44",
          }}
        >
          <span style={{ fontSize: 32 }}>✂️</span>
        </div>
        <h2 className="font-display text-xl font-bold text-center" style={{ color: "#f0ece0" }}>
          ¿Cómo fue tu experiencia?
        </h2>
        <p className="text-xs mt-1 text-center" style={{ color: "#7a7a7a" }}>
          {serviceName} con {professionalName}
        </p>
      </div>

      <div className="flex-1 px-5 py-6 flex flex-col gap-5">
        {/* Stars */}
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                className="star-btn"
                onMouseEnter={() => setHover(s)}
                onMouseLeave={() => setHover(0)}
                onClick={() => setStars(s)}
                style={{
                  fontSize: 44,
                  color: s <= (hover || stars) ? "#c9a84c" : "#2a2a2a",
                  filter: s <= (hover || stars) ? "drop-shadow(0 0 8px #c9a84c88)" : "none",
                  transition: "all 0.15s ease",
                }}
              >
                ★
              </button>
            ))}
          </div>
          {(hover || stars) > 0 && (
            <p className="text-sm font-semibold animate-fade-up" style={{ color: "#c9a84c" }}>
              {starLabels[hover || stars]}
            </p>
          )}
        </div>

        {/* Quick tags */}
        {stars > 0 && (
          <div className="animate-fade-up">
            <p className="text-xs font-medium mb-3" style={{ color: "#7a7a7a" }}>
              ¿Qué destacas? (opcional)
            </p>
            <div className="flex flex-wrap gap-2">
              {quickTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-150"
                  style={{
                    background: tags.includes(tag) ? "#1a1200" : "#1a1a1a",
                    border: `1px solid ${tags.includes(tag) ? "#c9a84c" : "#2a2a2a"}`,
                    color: tags.includes(tag) ? "#c9a84c" : "#7a7a7a",
                  }}
                >
                  {tags.includes(tag) ? "✓ " : ""}{tag}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Comment */}
        {stars > 0 && (
          <div className="animate-fade-up">
            <p className="text-xs font-medium mb-2" style={{ color: "#7a7a7a" }}>
              Tu opinión (opcional)
            </p>
            <textarea
              className="input-dark resize-none"
              rows={4}
              placeholder="Cuéntanos más sobre tu experiencia..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              style={{ lineHeight: 1.6 }}
            />
          </div>
        )}

        <div className="flex gap-3 mt-auto">
          <button
            className="flex-1 py-4 rounded-xl text-sm font-medium"
            style={{ background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#7a7a7a" }}
            onClick={onSkip}
          >
            Omitir
          </button>
          <button
            className="btn-primary flex-1 py-4 text-sm font-bold tracking-wider"
            onClick={handleSubmit}
            disabled={stars === 0}
            style={{ opacity: stars > 0 ? 1 : 0.4 }}
          >
            ENVIAR ★
          </button>
        </div>
      </div>
    </div>
  );
}
