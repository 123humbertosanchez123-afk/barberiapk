import { useState } from "react";
import { generateTimeSlots, professionals, services } from "../data/mockData";

interface CalendarScreenProps {
  preSelectedService?: string;
  preSelectedProfessional?: string;
  onBooked: (booking: BookingData) => void;
}

export interface BookingData {
  serviceId: string;
  professionalId: string;
  date: string;
  time: string;
}

const DAYS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay();
}

export default function CalendarScreen({ preSelectedService, preSelectedProfessional, onBooked }: CalendarScreenProps) {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedService, setSelectedService] = useState(preSelectedService || "s1");
  const [selectedPro, setSelectedPro] = useState(preSelectedProfessional || "p1");
  const [confirmed, setConfirmed] = useState(false);

  const timeSlots = generateTimeSlots();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  const isPast = (day: number) => {
    const d = new Date(year, month, day);
    const t = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    return d < t;
  };

  const service = services.find(s => s.id === selectedService);
  const pro = professionals.find(p => p.id === selectedPro);

  const handleConfirm = () => {
    if (!selectedDay || !selectedTime) return;
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(selectedDay).padStart(2, "0")}`;
    setConfirmed(true);
    setTimeout(() => {
      onBooked({ serviceId: selectedService, professionalId: selectedPro, date: dateStr, time: selectedTime });
    }, 1800);
  };

  if (confirmed) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-6 px-8">
        <div
          className="rounded-full flex items-center justify-center animate-logo-reveal"
          style={{ width: 100, height: 100, background: "#0a1a0a", border: "3px solid #22c55e", boxShadow: "0 0 40px #22c55e33" }}
        >
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2.5">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        <div className="text-center">
          <h2 className="font-display text-2xl font-bold mb-2" style={{ color: "#f0ece0" }}>¡Cita confirmada!</h2>
          <p className="text-sm" style={{ color: "#7a7a7a" }}>
            Tu reserva ha sido registrada exitosamente
          </p>
        </div>
        <div className="card-dark p-4 w-full rounded-2xl flex flex-col gap-2">
          <Row label="Servicio" value={service?.name || ""} />
          <Row label="Barbero" value={pro?.name || ""} />
          <Row label="Fecha" value={`${selectedDay} de ${MONTHS[month]} de ${year}`} />
          <Row label="Hora" value={selectedTime || ""} />
        </div>
      </div>
    );
  }

  return (
    <div className="screen-scroll">
      <div className="px-5 pt-8 pb-4">
        <h2 className="font-display text-2xl font-bold" style={{ color: "#f0ece0" }}>
          Reservar <span className="gold-shimmer">cita</span>
        </h2>
        <p className="text-xs mt-1" style={{ color: "#555" }}>Elige fecha y hora disponible</p>
      </div>

      {/* Service & Pro selectors */}
      <div className="px-5 mb-4 flex flex-col gap-2">
        <div className="flex gap-2">
          <div className="flex-1">
            <p className="text-xs mb-1" style={{ color: "#7a7a7a" }}>Servicio</p>
            <select
              className="input-dark text-xs"
              value={selectedService}
              onChange={e => setSelectedService(e.target.value)}
              style={{ background: "#1a1a1a" }}
            >
              {services.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <p className="text-xs mb-1" style={{ color: "#7a7a7a" }}>Barbero</p>
            <select
              className="input-dark text-xs"
              value={selectedPro}
              onChange={e => setSelectedPro(e.target.value)}
              style={{ background: "#1a1a1a" }}
            >
              {professionals.filter(p => p.available).map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Calendar */}
      <div className="px-5 mb-5">
        <div className="card-dark p-4 rounded-2xl">
          {/* Month nav */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={prevMonth} className="p-2 rounded-lg" style={{ background: "#1a1a1a" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
            <h3 className="font-display font-bold text-base" style={{ color: "#f0ece0" }}>
              {MONTHS[month]} {year}
            </h3>
            <button onClick={nextMonth} className="p-2 rounded-lg" style={{ background: "#1a1a1a" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          </div>

          {/* Day names */}
          <div className="grid grid-cols-7 mb-2">
            {DAYS.map(d => (
              <div key={d} className="text-center text-xs font-medium py-1" style={{ color: "#555" }}>
                {d}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDay }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const past = isPast(day);
              const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
              const selected = selectedDay === day;
              return (
                <button
                  key={day}
                  onClick={() => !past && setSelectedDay(day)}
                  disabled={past}
                  className="aspect-square rounded-full flex items-center justify-center text-xs font-medium transition-all duration-150"
                  style={{
                    background: selected ? "#c9a84c" : isToday ? "#1a1200" : "transparent",
                    color: selected ? "#000" : past ? "#333" : isToday ? "#c9a84c" : "#f0ece0",
                    border: isToday && !selected ? "1px solid #c9a84c44" : "1px solid transparent",
                    cursor: past ? "not-allowed" : "pointer",
                  }}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Time slots */}
      {selectedDay && (
        <div className="px-5 mb-5 animate-fade-up">
          <p className="text-xs font-medium tracking-wider mb-3 uppercase" style={{ color: "#7a7a7a" }}>
            Horarios disponibles — {selectedDay} {MONTHS[month]}
          </p>
          <div className="grid grid-cols-4 gap-2">
            {timeSlots.map((slot) => (
              <button
                key={slot.time}
                disabled={!slot.available}
                onClick={() => slot.available && setSelectedTime(slot.time)}
                className="py-2.5 rounded-xl text-xs font-medium transition-all duration-150"
                style={{
                  background: !slot.available ? "#111" : selectedTime === slot.time ? "#c9a84c" : "#1a1a1a",
                  color: !slot.available ? "#333" : selectedTime === slot.time ? "#000" : "#f0ece0",
                  border: `1px solid ${!slot.available ? "#1a1a1a" : selectedTime === slot.time ? "#c9a84c" : "#2a2a2a"}`,
                  cursor: slot.available ? "pointer" : "not-allowed",
                  textDecoration: !slot.available ? "line-through" : "none",
                }}
              >
                {slot.time}
              </button>
            ))}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ background: "#1a1a1a", border: "1px solid #2a2a2a" }} />
              <span className="text-xs" style={{ color: "#555" }}>Disponible</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ background: "#111" }} />
              <span className="text-xs" style={{ color: "#555" }}>Ocupado</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ background: "#c9a84c" }} />
              <span className="text-xs" style={{ color: "#555" }}>Seleccionado</span>
            </div>
          </div>
        </div>
      )}

      {selectedDay && selectedTime && (
        <div className="px-5 mb-6 animate-fade-up">
          <div
            className="p-4 rounded-2xl mb-4"
            style={{ background: "#0f0e00", border: "1px solid #c9a84c33" }}
          >
            <p className="text-xs font-semibold mb-2" style={{ color: "#c9a84c" }}>Resumen de tu cita</p>
            <div className="flex flex-col gap-1.5">
              <Row label="Servicio" value={service?.name || ""} />
              <Row label="Barbero" value={pro?.name || ""} />
              <Row label="Duración" value={`${service?.duration} min`} />
              <Row label="Fecha" value={`${selectedDay} ${MONTHS[month]} ${year}`} />
              <Row label="Hora" value={selectedTime} />
              <div className="flex justify-between mt-1 pt-2" style={{ borderTop: "1px solid #2a2a2a" }}>
                <span className="text-xs font-bold" style={{ color: "#f0ece0" }}>Total</span>
                <span className="text-sm font-bold" style={{ color: "#c9a84c" }}>
                  ${service?.price.toLocaleString("es-CO")}
                </span>
              </div>
            </div>
          </div>
          <button className="btn-primary w-full py-4 text-sm font-bold tracking-wider" onClick={handleConfirm}>
            CONFIRMAR RESERVA ✓
          </button>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-xs" style={{ color: "#7a7a7a" }}>{label}</span>
      <span className="text-xs font-medium" style={{ color: "#f0ece0" }}>{value}</span>
    </div>
  );
}
