import { useState } from "react";

interface LoginScreenProps {
  onLogin: () => void;
  onGoRegister: () => void;
}

export default function LoginScreen({ onLogin, onGoRegister }: LoginScreenProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  const handleLogin = () => {
    if (!email || !password) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin();
    }, 1200);
  };

  return (
    <div
      className="flex flex-col h-full overflow-y-auto"
      style={{ background: "radial-gradient(ellipse at top, #1a1200 0%, #0c0c0c 60%)" }}
    >
      {/* Header logo */}
      <div className="flex flex-col items-center pt-16 pb-10 px-6">
        <div
          className="flex items-center justify-center rounded-full mb-4 animate-gold-pulse"
          style={{
            width: 80,
            height: 80,
            background: "linear-gradient(135deg, #1a1200, #2a2000)",
            border: "2px solid #c9a84c",
            boxShadow: "0 0 24px #c9a84c33",
          }}
        >
          <svg width="40" height="40" viewBox="0 0 60 60" fill="none">
            <g transform="translate(30,30)">
              <line x1="-18" y1="-18" x2="0" y2="0" stroke="#c9a84c" strokeWidth="3" strokeLinecap="round" />
              <line x1="-10" y1="-18" x2="0" y2="0" stroke="#c9a84c" strokeWidth="3" strokeLinecap="round" />
              <circle cx="-14" cy="-22" r="5" stroke="#c9a84c" strokeWidth="2" fill="none" />
              <line x1="18" y1="18" x2="0" y2="0" stroke="#d4af37" strokeWidth="3" strokeLinecap="round" />
              <line x1="10" y1="18" x2="0" y2="0" stroke="#d4af37" strokeWidth="3" strokeLinecap="round" />
              <circle cx="14" cy="22" r="5" stroke="#d4af37" strokeWidth="2" fill="none" />
              <circle cx="0" cy="0" r="3" fill="#c9a84c" />
            </g>
          </svg>
        </div>
        <h1 className="font-display text-4xl gold-shimmer font-bold">ÉLITE</h1>
        <p className="text-xs tracking-[0.35em] mt-1 uppercase" style={{ color: "#7a6a40" }}>
          Barbershop
        </p>
      </div>

      {/* Form */}
      <div className="flex-1 px-6 flex flex-col gap-4">
        <div>
          <p className="text-lg font-semibold mb-1" style={{ color: "#f0ece0" }}>
            Bienvenido de vuelta
          </p>
          <p className="text-sm" style={{ color: "#555" }}>
            Inicia sesión para gestionar tus citas
          </p>
        </div>

        <div className="flex flex-col gap-3 mt-4">
          <div>
            <label className="text-xs font-medium mb-1 block" style={{ color: "#7a7a7a" }}>
              Correo electrónico
            </label>
            <input
              className="input-dark"
              type="email"
              placeholder="tu@correo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <label className="text-xs font-medium mb-1 block" style={{ color: "#7a7a7a" }}>
              Contraseña
            </label>
            <div className="relative">
              <input
                className="input-dark pr-12"
                type={showPass ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                className="absolute right-3 top-1/2 -translate-y-1/2"
                onClick={() => setShowPass(!showPass)}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="2">
                  {showPass ? (
                    <>
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                      <line x1="1" y1="1" x2="23" y2="23" />
                    </>
                  ) : (
                    <>
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                      <circle cx="12" cy="12" r="3" />
                    </>
                  )}
                </svg>
              </button>
            </div>
          </div>

          <button
            className="text-right text-xs mt-1"
            style={{ color: "#c9a84c" }}
          >
            ¿Olvidaste tu contraseña?
          </button>
        </div>

        <button
          className="btn-primary w-full py-4 mt-2 text-sm font-bold tracking-wider flex items-center justify-center gap-2"
          onClick={handleLogin}
          disabled={loading}
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
                <path d="M12 2a10 10 0 0 1 10 10" />
              </svg>
              Verificando...
            </span>
          ) : "INICIAR SESIÓN"}
        </button>

        <div className="flex items-center gap-3 my-2">
          <div className="flex-1 h-px" style={{ background: "#2a2a2a" }} />
          <span className="text-xs" style={{ color: "#444" }}>o</span>
          <div className="flex-1 h-px" style={{ background: "#2a2a2a" }} />
        </div>

        <button
          className="w-full py-4 text-sm font-medium rounded-xl flex items-center justify-center gap-2"
          style={{
            background: "#1a1a1a",
            border: "1px solid #2a2a2a",
            color: "#f0ece0",
          }}
          onClick={onGoRegister}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <line x1="19" y1="8" x2="19" y2="14" />
            <line x1="22" y1="11" x2="16" y2="11" />
          </svg>
          Crear cuenta nueva
        </button>
      </div>

      <div className="text-center py-6">
        <p className="text-xs" style={{ color: "#333" }}>
          Al continuar aceptas nuestros Términos y Condiciones
        </p>
      </div>
    </div>
  );
}
