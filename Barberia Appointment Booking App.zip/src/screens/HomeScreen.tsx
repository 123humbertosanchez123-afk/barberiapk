import { useState } from "react";
import { serviceCategories, services, professionalCategories, professionals } from "../data/mockData";
import type { UserData } from "./RegisterScreen";

interface HomeScreenProps {
  user: UserData;
  onBook: (serviceId: string, professionalId: string) => void;
}

type View = "home" | "services" | "professionals";

export default function HomeScreen({ user, onBook }: HomeScreenProps) {
  const [view, setView] = useState<View>("home");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProfCat, setSelectedProfCat] = useState<string | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);

  const filteredServices = selectedCategory ? services.filter((s) => s.categoryId === selectedCategory) : [];
  const filteredProfessionals = selectedProfCat
    ? professionals.filter((p) => p.categoryId === selectedProfCat)
    : professionals;

  if (view === "services") {
    return (
      <div className="screen-scroll">
        <div
          className="flex items-center gap-3 px-5 py-5 sticky top-0 z-20"
          style={{ background: "#0c0c0c", borderBottom: "1px solid #1e1e1e" }}
        >
          <button onClick={() => setView("home")} className="p-2 rounded-lg" style={{ background: "#1a1a1a" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
          <h2 className="font-display text-lg font-bold" style={{ color: "#f0ece0" }}>
            {serviceCategories.find((c) => c.id === selectedCategory)?.name}
          </h2>
        </div>

        <div className="px-5 py-4">
          <p className="text-xs mb-5" style={{ color: "#555" }}>
            Selecciona el servicio que deseas reservar
          </p>
          <div className="flex flex-col gap-3">
            {filteredServices.map((svc, i) => (
              <div
                key={svc.id}
                className="animate-fade-up"
                style={{ animationDelay: `${i * 0.05}s`, opacity: 0, animationFillMode: "forwards" }}
              >
                <button
                  className="w-full text-left p-4 rounded-2xl flex items-center gap-4 transition-all duration-200"
                  style={{
                    background: selectedService === svc.id ? "#1a1200" : "#161616",
                    border: `1px solid ${selectedService === svc.id ? "#c9a84c" : "#2a2a2a"}`,
                    boxShadow: selectedService === svc.id ? "0 0 16px #c9a84c22" : "none",
                  }}
                  onClick={() => setSelectedService(svc.id)}
                >
                  <div
                    className="rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ width: 44, height: 44, background: "#0f0e00" }}
                  >
                    <span style={{ fontSize: 20 }}>
                      {serviceCategories.find((c) => c.id === svc.categoryId)?.icon}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm" style={{ color: "#f0ece0" }}>{svc.name}</p>
                    <p className="text-xs mt-0.5" style={{ color: "#555" }}>{svc.description}</p>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="text-xs" style={{ color: "#7a7a7a" }}>⏱ {svc.duration} min</span>
                      <span className="text-xs font-bold" style={{ color: "#c9a84c" }}>
                        ${svc.price.toLocaleString("es-CO")}
                      </span>
                    </div>
                  </div>
                  {selectedService === svc.id && (
                    <div className="rounded-full flex items-center justify-center" style={{ width: 24, height: 24, background: "#c9a84c" }}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="3">
                        <polyline points="20 6 9 17 4 12" />
                      </svg>
                    </div>
                  )}
                </button>
              </div>
            ))}
          </div>

          {selectedService && (
            <button
              className="btn-primary w-full py-4 mt-6 text-sm font-bold tracking-wider"
              onClick={() => setView("professionals")}
            >
              SELECCIONAR PROFESIONAL →
            </button>
          )}
        </div>
      </div>
    );
  }

  if (view === "professionals") {
    return (
      <div className="screen-scroll">
        <div
          className="flex items-center gap-3 px-5 py-5 sticky top-0 z-20"
          style={{ background: "#0c0c0c", borderBottom: "1px solid #1e1e1e" }}
        >
          <button onClick={() => setView("services")} className="p-2 rounded-lg" style={{ background: "#1a1a1a" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#c9a84c" strokeWidth="2">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
          <h2 className="font-display text-lg font-bold" style={{ color: "#f0ece0" }}>
            Elige tu Barbero
          </h2>
        </div>

        <div className="px-5 py-4">
          {/* Category tabs */}
          <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
            <button
              className="flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-medium transition-all"
              style={{
                background: !selectedProfCat ? "#c9a84c" : "#1a1a1a",
                color: !selectedProfCat ? "#000" : "#7a7a7a",
                border: "1px solid #2a2a2a",
              }}
              onClick={() => setSelectedProfCat(null)}
            >
              Todos
            </button>
            {professionalCategories.map((cat) => (
              <button
                key={cat.id}
                className="flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-medium transition-all"
                style={{
                  background: selectedProfCat === cat.id ? "#c9a84c" : "#1a1a1a",
                  color: selectedProfCat === cat.id ? "#000" : "#7a7a7a",
                  border: "1px solid #2a2a2a",
                }}
                onClick={() => setSelectedProfCat(cat.id)}
              >
                {cat.name}
              </button>
            ))}
          </div>

          <div className="flex flex-col gap-3">
            {filteredProfessionals.map((pro, i) => (
              <div
                key={pro.id}
                className="animate-fade-up"
                style={{ animationDelay: `${i * 0.05}s`, opacity: 0, animationFillMode: "forwards" }}
              >
                <button
                  className="w-full text-left p-4 rounded-2xl flex items-center gap-4 transition-all duration-200"
                  style={{
                    background: "#161616",
                    border: "1px solid #2a2a2a",
                    opacity: pro.available ? 1 : 0.5,
                  }}
                  onClick={() => pro.available && onBook(selectedService!, pro.id)}
                  disabled={!pro.available}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={pro.avatar}
                      alt={pro.name}
                      className="rounded-full object-cover"
                      style={{ width: 56, height: 56, border: "2px solid #c9a84c44" }}
                    />
                    <div
                      className="absolute bottom-0 right-0 rounded-full"
                      style={{
                        width: 14, height: 14,
                        background: pro.available ? "#22c55e" : "#555",
                        border: "2px solid #0c0c0c",
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-sm" style={{ color: "#f0ece0" }}>{pro.name}</p>
                    <p className="text-xs" style={{ color: "#7a7a7a" }}>{pro.specialty}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <span style={{ color: "#c9a84c", fontSize: 12 }}>★</span>
                      <span className="text-xs font-bold" style={{ color: "#f0ece0" }}>{pro.rating}</span>
                      <span className="text-xs" style={{ color: "#555" }}>({pro.reviews} reseñas)</span>
                    </div>
                  </div>
                  <div>
                    {pro.available ? (
                      <span className="text-xs px-2 py-1 rounded-full" style={{ background: "#0a1a0a", color: "#22c55e", border: "1px solid #22c55e33" }}>
                        Disponible
                      </span>
                    ) : (
                      <span className="text-xs px-2 py-1 rounded-full" style={{ background: "#1a1a1a", color: "#555", border: "1px solid #2a2a2a" }}>
                        Ocupado
                      </span>
                    )}
                  </div>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Main home view
  return (
    <div className="screen-scroll">
      {/* Hero header */}
      <div
        className="px-5 pt-8 pb-6"
        style={{ background: "linear-gradient(180deg, #1a1200 0%, #0c0c0c 100%)" }}
      >
        <div className="flex items-center justify-between mb-1">
          <div>
            <p className="text-xs" style={{ color: "#7a7a7a" }}>Bienvenido,</p>
            <h1 className="font-display text-2xl font-bold" style={{ color: "#f0ece0" }}>
              {user.nombre} <span className="gold-shimmer">{user.apellido}</span>
            </h1>
          </div>
          <div
            className="rounded-full overflow-hidden"
            style={{ width: 44, height: 44, border: "2px solid #c9a84c" }}
          >
            {user.photo ? (
              <img src={user.photo} alt="Perfil" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: "#1a1200" }}>
                <span className="text-lg font-bold" style={{ color: "#c9a84c" }}>
                  {user.nombre[0]}
                </span>
              </div>
            )}
          </div>
        </div>
        <p className="text-xs mt-1" style={{ color: "#555" }}>¿Qué servicio necesitas hoy?</p>
      </div>

      {/* Promo banner */}
      <div className="px-5 mb-5">
        <div
          className="p-4 rounded-2xl flex items-center gap-4"
          style={{
            background: "linear-gradient(135deg, #1a1200, #0f0e00)",
            border: "1px solid #c9a84c44",
            boxShadow: "0 4px 24px #c9a84c11",
          }}
        >
          <div>
            <p className="text-xs font-semibold" style={{ color: "#c9a84c" }}>🔥 OFERTA DEL DÍA</p>
            <p className="text-sm font-bold mt-0.5" style={{ color: "#f0ece0" }}>Combo Caballero 20% OFF</p>
            <p className="text-xs" style={{ color: "#7a7a7a" }}>Solo hoy — Válido hasta las 7pm</p>
          </div>
          <div className="ml-auto">
            <span className="text-3xl">✂️</span>
          </div>
        </div>
      </div>

      {/* Service categories */}
      <div className="px-5 mb-6">
        <p className="text-xs font-medium tracking-wider mb-3 uppercase" style={{ color: "#7a7a7a" }}>
          Categorías de servicios
        </p>
        <div className="grid grid-cols-2 gap-3">
          {serviceCategories.map((cat, i) => (
            <button
              key={cat.id}
              className="animate-fade-up p-4 rounded-2xl text-left flex flex-col gap-2 transition-all duration-200 active:scale-95"
              style={{
                background: "#161616",
                border: "1px solid #2a2a2a",
                animationDelay: `${i * 0.08}s`,
                opacity: 0,
                animationFillMode: "forwards",
              }}
              onClick={() => {
                setSelectedCategory(cat.id);
                setSelectedService(null);
                setView("services");
              }}
            >
              <div
                className="rounded-xl flex items-center justify-center"
                style={{ width: 44, height: 44, background: "#0f0e00" }}
              >
                <span style={{ fontSize: 22 }}>{cat.icon}</span>
              </div>
              <div>
                <p className="font-semibold text-sm" style={{ color: "#f0ece0" }}>{cat.name}</p>
                <p className="text-xs" style={{ color: "#555" }}>
                  {services.filter((s) => s.categoryId === cat.id).length} servicios
                </p>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#c9a84c44" strokeWidth="2">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* Top professionals */}
      <div className="px-5 mb-4">
        <p className="text-xs font-medium tracking-wider mb-3 uppercase" style={{ color: "#7a7a7a" }}>
          Barberos destacados
        </p>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {professionals.filter((p) => p.available).slice(0, 4).map((pro) => (
            <div
              key={pro.id}
              className="flex-shrink-0 flex flex-col items-center gap-2"
            >
              <div className="relative">
                <img
                  src={pro.avatar}
                  alt={pro.name}
                  className="rounded-full object-cover"
                  style={{ width: 60, height: 60, border: "2px solid #c9a84c55" }}
                />
                <div
                  className="absolute bottom-0 right-0 rounded-full"
                  style={{ width: 14, height: 14, background: "#22c55e", border: "2px solid #0c0c0c" }}
                />
              </div>
              <p className="text-xs font-medium text-center w-16 truncate" style={{ color: "#f0ece0" }}>
                {pro.name.split(" ")[0]}
              </p>
              <div className="flex items-center gap-0.5">
                <span style={{ color: "#c9a84c", fontSize: 10 }}>★</span>
                <span className="text-xs" style={{ color: "#7a7a7a" }}>{pro.rating}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
