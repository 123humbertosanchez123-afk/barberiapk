export interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface Service {
  id: string;
  categoryId: string;
  name: string;
  duration: number; // minutes
  price: number;
  description: string;
}

export interface ProfessionalCategory {
  id: string;
  name: string;
  level: string;
}

export interface Professional {
  id: string;
  categoryId: string;
  name: string;
  specialty: string;
  rating: number;
  reviews: number;
  avatar: string;
  available: boolean;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export const serviceCategories: ServiceCategory[] = [
  { id: "cut", name: "Cortes", icon: "✂️", color: "#c9a84c" },
  { id: "beard", name: "Barba", icon: "🪒", color: "#8a7040" },
  { id: "treatment", name: "Tratamientos", icon: "💆", color: "#5a4a2a" },
  { id: "combo", name: "Combos", icon: "⭐", color: "#d4af37" },
];

export const services: Service[] = [
  { id: "s1", categoryId: "cut", name: "Corte Clásico", duration: 30, price: 25000, description: "Corte tradicional con tijeras y máquina" },
  { id: "s2", categoryId: "cut", name: "Fade / Degradado", duration: 45, price: 35000, description: "Degradado perfecto a tu estilo" },
  { id: "s3", categoryId: "cut", name: "Corte + Diseño", duration: 60, price: 45000, description: "Corte con diseño personalizado" },
  { id: "s4", categoryId: "cut", name: "Corte Infantil", duration: 25, price: 20000, description: "Para los pequeños del hogar" },
  { id: "s5", categoryId: "beard", name: "Perfilado de Barba", duration: 20, price: 18000, description: "Definición y líneas limpias" },
  { id: "s6", categoryId: "beard", name: "Afeitado Clásico", duration: 30, price: 25000, description: "Afeitado con navaja y toalla caliente" },
  { id: "s7", categoryId: "beard", name: "Barba Completa", duration: 40, price: 30000, description: "Corte, moldeado y tratamiento de barba" },
  { id: "s8", categoryId: "treatment", name: "Hidratación Capilar", duration: 45, price: 40000, description: "Nutrición profunda para tu cabello" },
  { id: "s9", categoryId: "treatment", name: "Keratina Express", duration: 60, price: 65000, description: "Alisado y brillo intenso" },
  { id: "s10", categoryId: "treatment", name: "Coloración", duration: 90, price: 80000, description: "Coloración profesional completa" },
  { id: "s11", categoryId: "combo", name: "Combo Caballero", duration: 75, price: 55000, description: "Corte + Barba + Hidratación" },
  { id: "s12", categoryId: "combo", name: "Combo Premium", duration: 120, price: 90000, description: "Corte + Barba + Tratamiento completo" },
];

export const professionalCategories: ProfessionalCategory[] = [
  { id: "senior", name: "Senior Barbers", level: "Maestros con más de 5 años" },
  { id: "junior", name: "Junior Barbers", level: "Profesionales en formación" },
  { id: "specialist", name: "Especialistas", level: "Expertos en tratamientos" },
];

export const professionals: Professional[] = [
  { id: "p1", categoryId: "senior", name: "Carlos Mendoza", specialty: "Fade & Diseño", rating: 4.9, reviews: 312, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop&auto=format", available: true },
  { id: "p2", categoryId: "senior", name: "Andrés Ríos", specialty: "Clásico & Afeitado", rating: 4.8, reviews: 278, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&auto=format", available: true },
  { id: "p3", categoryId: "junior", name: "Diego Vargas", specialty: "Fade Moderno", rating: 4.6, reviews: 134, avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&h=120&fit=crop&auto=format", available: false },
  { id: "p4", categoryId: "junior", name: "Sebastián Torres", specialty: "Diseño & Arte", rating: 4.7, reviews: 89, avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&h=120&fit=crop&auto=format", available: true },
  { id: "p5", categoryId: "specialist", name: "Miguel Herrera", specialty: "Tratamientos Capilares", rating: 4.9, reviews: 201, avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop&auto=format", available: true },
];

export const generateTimeSlots = (): TimeSlot[] => {
  const slots: TimeSlot[] = [];
  const times = ["08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30"];
  const occupied = ["09:00", "10:30", "11:30", "14:00", "15:30", "17:00"];
  times.forEach(t => slots.push({ time: t, available: !occupied.includes(t) }));
  return slots;
};

export const generateCode = () => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  return "BAR-" + Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
};
